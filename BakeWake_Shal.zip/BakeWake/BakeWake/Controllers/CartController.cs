﻿using BakeWake.Services.IService;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BakeWake.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        
        private readonly ICartService _serv;
        public CartController(ICartService serv)
        {
            _serv = serv;
        }
        [HttpGet]
        [Route("{userId:int}/GetCartItems")]
        public async Task<IActionResult> GetCart(int userId)
        {
            var result = await _serv.GetAllCartItems(userId);
            return Ok(result);
        }



        [HttpPost]
        [Route("AddItemToCart")]
        public async Task<IActionResult> PostCart(int productId, int userId)
        {
            var result = await _serv.AddToCart(productId, userId);


            return Ok(result);
        }
        [HttpDelete]
        [Route("RemoveItem")]
        public async Task<IActionResult> RemoveItem(int productId, int userId)
        {
            var cart = await _serv.RemoveItem(productId, userId);
            if (cart == null)
            {
                return NotFound();
            }
            return Ok("Item removed from Cart");
        }

        [HttpGet]
        [Route("TotalPrice")]
        public async Task<IActionResult> GetTotalPrice(int userId)
        {
            var result = await _serv.GetToTalPrice(userId);
            return Ok(result);
        }
    }
}
