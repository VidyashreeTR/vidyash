﻿using BakeWake.Models;
using BakeWake.Services.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BakeWake.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _serv;
        public ProductController(IProductService serv)
        {
            _serv = serv;
        }
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllProduct()
        {
            var result = await _serv.Get();
            return Ok(result);
        }
        [HttpGet]
        [Route("{id:int}/GetById")]
        [AllowAnonymous]
        public async Task<IActionResult> GetbyId([FromRoute] int id)
        {
            //var result = await _context.Products.FirstOrDefaultAsync(x => x.ProductId == id);
            var result = await _serv.GetById(id);
            return Ok(result);
        }
        [HttpGet]
        [AllowAnonymous]
        [Route("{categoryname}/GetByCategoryName")]
        public async Task<IActionResult> ProductByCategoryName(string categoryname)
        {
            return Ok(await _serv.ProductByCategoryName(categoryname));
            /*if(result==null)
            {
                return NotFound("Category doesn't exixst");
            }
            
            return Ok(result);*/
        }
        [HttpPost]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> InsertProduct(Product product)
        {
            /*await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();*/
            await _serv.Insert(product);
            return Ok(product);
        }
        [HttpGet]
        [Route("{price}/searchByPrice")]
        [AllowAnonymous]
        public async Task<IActionResult> GetByPrice(int price)
        {
            return Ok(await _serv.GetByPrice(price));
        }
        [HttpPut]
        [Route("{id:int}")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateProduct([FromRoute] int id, [FromBody] Product product)
        {
            /* var result = await _context.Products.FirstOrDefaultAsync(x => x.ProductId == id);
             if (result == null) { return NotFound(); }
             result.ProductName = product.ProductName;
             result.ProductPrice = product.ProductPrice;45 
             result.Brand = product.Brand;
             result.Quantity = product.Qantity;
             result.CatId = product.CatId;
             await _context.SaveChangesAsync();*/
            var result = await _serv.Update(id, product);
            return Ok(result);
        }
        [HttpDelete]
        [Route("{id:int}")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteProduct([FromRoute] int id)
        {
            /*var result = await _context.Products.FirstOrDefaultAsync(x => x.ProductId == id);
            if (result == null) { return NotFound(); }
            _context.Products.Remove(result);
            await _context.SaveChangesAsync();*/
            var result = await _serv.Delete(id);
            return Ok(result);
        }
    }
}
