﻿using BakeWake.Models;
using BakeWake.Services.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BakeWake.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _serv;
        public UserController(IUserService serv)
        {
            _serv = serv;
        }
        [HttpGet]
        //[Authorize(Roles ="Admin")]
        public async Task<IActionResult> Get()
        {
            //var result = await _context.Users.ToListAsync();
            var result = await _serv.Get();
            return Ok(result);
        }
        [HttpGet]
        [Route("{id:int}")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> GetbyId([FromRoute] int id)
        {
            //var result = await _context.Users.FirstOrDefaultAsync(x => x.UserId == id);
            var result = await _serv.GetById(id);
            return Ok(result);
        }
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Insert(User user)
        {
            /*await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();*/
            await _serv.Insert(user);
            return Ok(user);

        }
        [HttpPut]
        [Route("{id:int}")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] User user)
        {
            /*var result = await _context.Users.FirstOrDefaultAsync(x => x.UserId == id);
            if (result == null) { return NotFound(); }
            result.UserName = user.UserName;
            result.UserEmail = user.UserEmail;
            result.Password = user.Password;
            result.ConfirmPassword=user.ConfirmPassword;
            result.Phonenumber = user.Phonenumber;
            result.role = user.role;
            result.Address = user.Address;
            await _context.SaveChangesAsync();*/

            var result = await _serv.Update(id, user);
            return Ok(result);

        }
        [HttpDelete]
        [Route("{id:int}")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            /*var result = await _context.Users.FirstOrDefaultAsync(x => x.UserId == id);
            if (result == null) { return NotFound(); }
            _context.Users.Remove(result);
            await _context.SaveChangesAsync();*/
            var result = await _serv.Delete(id);
            return Ok(result);
        }
        [HttpPut]
        [Route("{id:int}/UpdateAsAdmin")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateAsAdmin([FromRoute] int id)
        {
            var result = await _serv.UpdateAsAdmin(id);
            return Ok(result);
        }
        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login(string UserEmail, string Password)
        {
            string result = await _serv.Login(UserEmail, Password);

            if (result == null)
            {
                return NotFound("The Entered UserEmail or Password is Not Correct.");
            }
            return Ok(result);
        }
    }
}
