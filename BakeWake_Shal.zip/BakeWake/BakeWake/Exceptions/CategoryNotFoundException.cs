﻿namespace BakeWake.Exceptions
{
    public class CategoryNotFoundException : ApplicationException
    {
        public CategoryNotFoundException() { }

        public CategoryNotFoundException(string msg) : base(msg) { }
    }
}
