﻿namespace BakeWake.Exceptions
{
    public class ProductAlreadyExsistException :ApplicationException
    {
        public ProductAlreadyExsistException() { }
        public ProductAlreadyExsistException(string msg) : base(msg) { }

    }
}
