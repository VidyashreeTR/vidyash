﻿namespace BakeWake.Exceptions
{
    public class UserAlreadyExsistException : ApplicationException
    {
        public UserAlreadyExsistException() { }
        public UserAlreadyExsistException(string msg) : base(msg) { }
    }
}
