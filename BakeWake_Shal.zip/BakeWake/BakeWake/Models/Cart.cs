﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BakeWake.Models
{
    public class Cart
    {
        public int CartID { get; set; }
        [ForeignKey("Product")]
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        //public Product? Product { get; set; }
        [ForeignKey("User")]
        public int UserId { get; set; }
        public string UserName { get; set; }
        //public User? User { get; set; }        
        public int Quantity { get; set; }
        public int UnitPrice { get; set; }
    }
}
