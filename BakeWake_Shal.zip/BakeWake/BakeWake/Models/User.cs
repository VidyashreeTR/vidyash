﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace BakeWake.Models
{
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UserId { get; set; }
        [Required(ErrorMessage = "Email is required")]
        public string? UserEmail { get; set; }
        [Required]
        public string? UserName { get; set; }
        [Required(ErrorMessage = "Password is required")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$", ErrorMessage = "Password must be 8 character long and it should contain a capital letter and small letter and number and at least one special character")]
        public string? Password { get; set; }
        [Required]
        [Compare("Password", ErrorMessage = "The Password is not Matching")]
        public string? ConfirmPassword { get; set; }
        [DefaultValue("User")]
        public string? Role { get; set; }
        [Required(ErrorMessage = "Phone Number is required")]
        [RegularExpression(@"^[7,8,9]{1}\d{9}$", ErrorMessage = "Invalid Mobile Number")]
        public long PhoneNumber { get; set; }
        public string? Address { get; set; }
    }
}
