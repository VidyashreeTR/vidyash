﻿using BakeWake.Models;

namespace BakeWake.Repositories.IRepository
{
    public interface IOrderRepository
    {
        Task<List<Order>> Get();
        Task<Order> BuyNow(int userId);
        Task<int> GetTotalAmount(int userId);
    }
}
