﻿using BakeWake.Models;

namespace BakeWake.Repositories.IRepository
{
    public interface IProductRepository
    {
        Task<List<Product>> Get();
        Task<Product> GetById(int id);
        Task<Product> Insert(Product products);
        Task<List<Product>> GetByPrice(int price);
        Task<List<Product>> ProductByCategoryName(string categoryname);
        Task<Product> Update(int id, Product products);
        Task<Product> Delete(int id);
    }
}
