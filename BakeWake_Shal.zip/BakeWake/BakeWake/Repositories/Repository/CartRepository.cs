﻿using BakeWake.Models;
using BakeWake.Repositories.IRepository;
using Microsoft.EntityFrameworkCore;

namespace BakeWake.Repositories.Repository
{
    public class CartRepository : ICartRepository
    {
        private readonly VTRDbContext _context;
        public CartRepository(VTRDbContext context)
        {
            _context = context;
        }
        public async Task<List<Cart>> GetAllCartItems(int userId)
        {
            return await _context.Cart.Where(t => t.UserId == userId).ToListAsync();
        }
        public async Task<Cart> AddToCart(int productId, int userId)
        {
            var productExist = await _context.Cart.FirstOrDefaultAsync(t => t.ProductId == productId && t.UserId == userId);
            if (productExist == null)
            {
                productExist = new Cart
                {
                    ProductId = productId,
                    UserId = userId,
                    Quantity = 1,
                    UserName = _context.User.SingleOrDefault(t => t.UserId == userId).UserName,
                    ProductName = _context.Product.SingleOrDefault(t => t.ProductId == productId).ProductName,
                    UnitPrice = _context.Product.SingleOrDefault(t => t.ProductId == productId).ProductPrice
                };
                await _context.Cart.AddAsync(productExist);
            }
            else
            {
                productExist.Quantity++;
            }
            await _context.SaveChangesAsync();
            return productExist;
        }
        public async Task<Cart> RemoveItem(int productId, int userId)
        {
            var result = _context.Cart.FirstOrDefault(t => t.ProductId == productId && t.UserId == userId);
            if (result == null)
            {
                return null;
            }
            _context.Cart.Remove(result);
            await _context.SaveChangesAsync();
            return result; ;
        }
        public async Task<int> GetToTalPrice(int userId)
        {
            int sum = 0;
            var items = await GetAllCartItems(userId);
            foreach (var item in items)
            {
                sum += item.UnitPrice * item.Quantity;
            }
            return sum;
        }
    }
}
