﻿using BakeWake.Models;
using BakeWake.Repositories.IRepository;
using Microsoft.EntityFrameworkCore;

namespace BakeWake.Repositories.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly VTRDbContext _context;

        public CategoryRepository(VTRDbContext context)
        {
            _context = context;
        }


        public async Task<List<Category>> Get()
        {
            return await _context.Category.ToListAsync();
        }


        public async Task<Category> GetById(int id)
        {
            var result = await _context.Category.FirstOrDefaultAsync(x => x.CatId == id);

            if (result == null)
            {
                return null;
            }

            return result;
        }

        public async Task<Category> Update(int id, Category category)
        {
            var result = await _context.Category.FirstOrDefaultAsync(x => x.CatId == id);
            if (result == null) { return null; }
            result.CatName = category.CatName;
            await _context.SaveChangesAsync();
            return result;
        }


        public async Task<Category> Insert(Category category)
        {
            _context.Category.AddAsync(category);
            await _context.SaveChangesAsync();

            return category;
        }


        public async Task<Category> Delete(int id)
        {
            var result = await _context.Category.FirstOrDefaultAsync(x => x.CatId == id);
            if (result == null)
            {
                return null;
            }

            _context.Category.Remove(result);
            await _context.SaveChangesAsync();

            return result;
        }

    }
}
