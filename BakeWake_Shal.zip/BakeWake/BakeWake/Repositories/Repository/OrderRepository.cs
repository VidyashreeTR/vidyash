﻿using BakeWake.Models;
using BakeWake.Repositories.IRepository;
using Microsoft.EntityFrameworkCore;

namespace BakeWake.Repositories.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly VTRDbContext _context;
        private readonly ICartRepository _cartRepository;
        public OrderRepository(VTRDbContext context, ICartRepository cartRepository)
        {
            _context = context;
            _cartRepository = cartRepository;
        }
        public async Task<List<Order>> Get()
        {
            return await _context.Order.ToListAsync();
        }
        public async Task<Order> BuyNow(int userId)
        {
            var items = await _cartRepository.GetAllCartItems(userId);

            foreach (var item in items)
            {
                _context.Cart.Remove(item);
                var result = _context.Product.FirstOrDefault(x => x.ProductId == item.ProductId);
                result.Quantity -= item.Quantity;
            }
            var order = new Order
            {
                UserId = userId,
                TotalAmount = await GetTotalAmount(userId)
            };
            await _context.Order.AddAsync(order);
            _context.SaveChanges();
            return order;


        }
        public async Task<int> GetTotalAmount(int userId)
        {
            return await _cartRepository.GetToTalPrice(userId);
        }
    }
}
