﻿using BakeWake.Models;
using BakeWake.Repositories.IRepository;
using Microsoft.EntityFrameworkCore;

namespace BakeWake.Repositories.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly VTRDbContext _context;

        public ProductRepository(VTRDbContext context)
        {
            _context = context;
        }
        public async Task<List<Product>> Get()
        {
            return await _context.Product.ToListAsync();
        }

        public async Task<Product> GetById(int id)
        {
            var result = await _context.Product.FindAsync(id);

            if (result == null)
            {
                return null;
            }

            return result;
        }
        public async Task<List<Product>> GetByPrice(int price)
        {

            string filterByPrice = "exec FilterPrdPrice @price = " + price;
            return await _context.Product.FromSqlRaw(filterByPrice).ToListAsync();
        }
        public async Task<List<Product>> ProductByCategoryName(string categoryname)
        {
            string filterbyname = "exec Productbycategoryname @catname =" + categoryname;
            return _context.Product.FromSqlRaw(filterbyname).ToList();
        }
        public async Task<Product> Update(int id, Product product)
        {
            var result = _context.Product.FirstOrDefault(x => x.ProductId == id);
            if (result == null) { return null; }
            result.ProductName = product.ProductName;
            result.ProductPrice = product.ProductPrice;
            result.Brand = product.Brand;
            result.Quantity = product.Quantity;
            result.CatId = product.CatId;
            _context.SaveChanges();
            return result;

        }

        public async Task<Product> Insert(Product product)
        {
            _context.Product.AddAsync(product);
            await _context.SaveChangesAsync();

            return product;
        }


        public async Task<Product> Delete(int id)
        {
            var result = await _context.Product.FirstOrDefaultAsync(x => x.ProductId == id);
            if (result == null)
            {
                return null;
            }

            _context.Product.Remove(result);
            await _context.SaveChangesAsync();

            return result;
        }
    }
}
