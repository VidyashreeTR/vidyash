﻿using BakeWake.Models;

namespace BakeWake.Services.IService
{
    public interface ICartService
    {
        Task<Cart> AddToCart(int productId, int userId);
        Task<List<Cart>> GetAllCartItems(int userId);

        Task<int> GetToTalPrice(int userId);
        Task<Cart> RemoveItem(int productId, int userId);
    }
}
