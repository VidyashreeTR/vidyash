﻿using BakeWake.Models;

namespace BakeWake.Services.IService
{
    public interface ICategoryService
    {
        Task<List<Category>> Get();
        Task<Category> GetById(int id);
        Task<Category> Insert(Category category);
        Task<Category> Update(int id, Category category);
        Task<Category> Delete(int id);
    }
}
