﻿using BakeWake.Models;

namespace BakeWake.Services.IService
{
    public interface IUserService
    {
        Task<List<User>> Get();
        Task<User> GetById(int id);
        Task<User> Insert(User user);
        Task<User> Update(int id, User user);
        Task<string> Delete(int id);
        Task<User> UpdateAsAdmin(int id);
        Task<string> Login(string UserEmail, string Password);
    }
}
