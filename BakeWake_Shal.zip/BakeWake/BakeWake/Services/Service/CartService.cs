﻿using BakeWake.Exceptions;
using BakeWake.Models;
using BakeWake.Repositories.IRepository;
using BakeWake.Services.IService;

namespace BakeWake.Services.Service
{
    public class CartService : ICartService
    {
        private readonly ICartRepository _cartrepo;
        private readonly IProductRepository _prorepo;
        private readonly IUserRepository _userrepo;
        public CartService(ICartRepository cartrepo, IProductRepository prorepo, IUserRepository userrepo)
        {
            _cartrepo = cartrepo;
            _prorepo = prorepo;
            _userrepo = userrepo;
        }
        public async Task<Cart> AddToCart(int productId, int userId)
        {
            if (await _prorepo.GetById(productId) == null)
            {
                throw new ProductNotFoundException($"Product with Product id {productId} does not exists");
            }
            if (await _userrepo.GetById(userId) == null)
            {
                throw new UserNotFoundException($"The User with User id {userId} has not found");
            }
            return await _cartrepo.AddToCart(productId, userId);
        }
        public async Task<List<Cart>> GetAllCartItems(int userId)
        {
            if (await _userrepo.GetById(userId) == null)
            {
                throw new UserNotFoundException($"The User with User id {userId} has not found");
            }
            return await _cartrepo.GetAllCartItems(userId);
        }
        public async Task<int> GetToTalPrice(int userId)
        {
            if (await _userrepo.GetById(userId) == null)
            {
                throw new UserNotFoundException($"The User with User id {userId} has not found");
            }
            return await _cartrepo.GetToTalPrice(userId);
        }
        public async Task<Cart> RemoveItem(int productId, int userId)
        {
            if (await _prorepo.GetById(productId) == null)
            {
                throw new ProductNotFoundException($"Product with Product id {productId} does not exists");
            }
            if (await _userrepo.GetById(userId) == null)
            {
                throw new UserNotFoundException($"The User with User id {userId} has not found");
            }
            return await _cartrepo.RemoveItem(productId, userId);
        }
    }
}
