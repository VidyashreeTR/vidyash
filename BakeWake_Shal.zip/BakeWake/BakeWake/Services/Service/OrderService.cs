﻿using BakeWake.Exceptions;
using BakeWake.Models;
using BakeWake.Repositories.IRepository;
using BakeWake.Services.IService;

namespace BakeWake.Services.Service
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderrepo;
        private readonly IUserRepository _userrepo;
        private readonly ICartRepository _cartrepo;

        public OrderService(IOrderRepository orderrepo, IUserRepository userrepo, ICartRepository cartrepo)
        {
            _orderrepo = orderrepo;
            _userrepo = userrepo;
            _cartrepo = cartrepo;
        }
        public async Task<List<Order>> Get()
        {
            return await _orderrepo.Get();
        }
        public async Task<Order> BuyNow(int userId)
        {
            if (await _cartrepo.GetAllCartItems(userId) == null)
            {
                throw new UserNotFoundException($"The User with User id {userId} has not found");
            }
            return await _orderrepo.BuyNow(userId);
        }
        public async Task<int> GetTotalAmount(int userId)
        {
            if (await _userrepo.GetById(userId) == null)
            {
                throw new UserNotFoundException($"The User with User id {userId} has not found");
            }
            return await _orderrepo.GetTotalAmount(userId);
        }
    }
}
