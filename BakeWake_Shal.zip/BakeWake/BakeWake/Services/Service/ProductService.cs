﻿using BakeWake.Exceptions;
using BakeWake.Models;
using BakeWake.Repositories.IRepository;
using BakeWake.Services.IService;

namespace BakeWake.Services.Service
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _prorepo;
        public ProductService(IProductRepository prorepo)
        {
            _prorepo = prorepo;
        }
        public async Task<List<Product>> Get()
        {
            return await _prorepo.Get();
        }
        public async Task<Product> GetById(int id)
        {
            if (await _prorepo.GetById(id) == null)
            {
                throw new ProductNotFoundException($"Product with Product id {id} does not exists");
            }
            return await _prorepo.GetById(id);
        }
        public async Task<List<Product>> ProductByCategoryName(string categoryname)
        {
            return await _prorepo.ProductByCategoryName(categoryname);
        }
        public async Task<Product> Insert(Product product)
        {
            if (await _prorepo.GetById(product.ProductId) != null)
            {
                throw new ProductAlreadyExsistException($"Product with Product id  {product.ProductId} already exists");
            }
            return await _prorepo.Insert(product);
        }
        public async Task<List<Product>> GetByPrice(int price)
        {
            return await _prorepo.GetByPrice(price);
        }
        public async Task<Product> Update(int id, Product product)
        {
            if (await _prorepo.GetById(id) == null)
            {
                throw new ProductNotFoundException($"Product with Product id {id} does not exists");
            }
            return await _prorepo.Update(id, product);
        }
        public async Task<Product> Delete(int id)
        {
            if (await _prorepo.GetById(id) == null)
            {
                throw new ProductNotFoundException($"Product with Product id {id} does not exists");
            }
            return await _prorepo.Delete(id);
        }
    }
}
