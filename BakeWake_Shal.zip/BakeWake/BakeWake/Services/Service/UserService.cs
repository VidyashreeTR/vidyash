﻿using BakeWake.Exceptions;
using BakeWake.Models;
using BakeWake.Repositories.IRepository;
using BakeWake.Services.IService;

namespace BakeWake.Services.Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userrepo;
        public UserService(IUserRepository userrepo)
        {
            _userrepo = userrepo;
        }
        public async Task<List<User>> Get()
        {
            return await _userrepo.Get();
        }
        public async Task<User> GetById(int id)
        {
            return await _userrepo.GetById(id);
        }

        public async Task<User> Insert(User user)
        {
            if (await _userrepo.UserExists(user) != null)
            {
                throw new UserAlreadyExsistException($"The User with user email {user.UserEmail} is already exsist");
            }
            return await _userrepo.Insert(user);
        }
        public async Task<User> Update(int id, User user)
        {
            if (await _userrepo.GetById(id) == null)
            {
                throw new UserNotFoundException($"The User with User id {id} has not found");
            }
            return await _userrepo.Update(id, user);
        }
        public async Task<string> Delete(int id)
        {
            return _userrepo.Delete(id);
        }
        public async Task<User> UpdateAsAdmin(int id)
        {
            if (await _userrepo.GetById(id) == null)
            {
                throw new UserNotFoundException($"The User with User id {id} has not found");
            }
            return await _userrepo.UpdateAsAdmin(id);
        }
        public async Task<string> Login(string username, string password)
        {
            return _userrepo.Login(username, password);
        }
    }
}
