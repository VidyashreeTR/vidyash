﻿CREATE PROCEDURE [dbo].[Productbycategoryname]
	@catname varchar(30)
AS
	SELECT * from Product where CatId = (select CatId from Category where CatName = @catname)
RETURN 0;

