﻿CREATE PROCEDURE [dbo].[FilterPrdPrice]
	@price int
AS
	select * from dbo.Product Where ProductPrice<=@price
RETURN 0
